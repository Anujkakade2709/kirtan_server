package org.iskon.kirtan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KirtanApplicationTests {

	@Test
	void contextLoads() {
	}

}
