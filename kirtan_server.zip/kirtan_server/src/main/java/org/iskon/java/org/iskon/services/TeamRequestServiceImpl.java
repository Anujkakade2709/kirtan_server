package org.iskon.services;

import java.util.List;
import java.util.Map;

import org.iskon.models.TeamRequest;
import org.iskon.repositories.TeamRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TeamRequestServiceImpl implements TeamRequestService {

    TeamRequestRepository teamRequestRepository;
	
	@Autowired
	public TeamRequestServiceImpl(TeamRequestRepository teamRequestRepository)
	{
		this.teamRequestRepository = teamRequestRepository;
	}

	@Override
	public TeamRequest submitNewTeamRequest(TeamRequest teamRequest) 
	{
		return this.teamRequestRepository.submitNewTeamRequest(teamRequest);
	}
	
	
	@Override
	public List<TeamRequest> getTeamRequests(Map<String, Object> query) {
		
		return this.teamRequestRepository.getTeamRequests(query);
	}

	@Override
	public Boolean processTeamRequest(Map<String,Object> params) {
		// validate input
		// Obtain user from current principal after security is implemented
		System.out.println(params);
		Boolean result = this.teamRequestRepository.processTeamRequest((Integer)params.get("teamId"), 
				(String)params.get("approvalStatus"), (String)params.get("approvalComments"),"Srinivas");
		if(result)
		{
			// Send Email
		}
		
		return result;
	}
	
	@Override
	public Boolean deleteTeamRequest(Map<String,Object> params) {
		// validate input
		// Obtain user from current principal after security is implemented
		System.out.println(params);
		Boolean result = this.teamRequestRepository.deleteTeamRequest((Integer)params.get("teamId"));
		if(result)
		{
			// Send Email
		}
		
		return result;
	}

}
