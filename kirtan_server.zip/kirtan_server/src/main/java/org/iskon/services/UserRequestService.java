package org.iskon.services;

import java.util.List;
import java.util.Map;

import org.iskon.models.UserRequest;

public interface UserRequestService {
	
	UserRequest submitNewUserRequest(UserRequest userRequest);
	
	List<UserRequest> getUserRequests(Map<String,Object> query);
	
	Boolean processUserRequest(Map<String,Object> params);

	Boolean deleteUserRequest(Map<String, Object> params);

	UserRequest submitUpdateUserRequest(UserRequest newUserRequest);
}
